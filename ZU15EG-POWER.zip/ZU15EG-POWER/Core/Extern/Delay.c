#include "Delay.h"
#include "tim.h"


void Delay_us(uint16_t delay_time){
	HAL_TIM_Base_Start(&htim2);
	while(TIM2->CNT < delay_time)
	{
	}
	HAL_TIM_Base_Stop(&htim2);
}