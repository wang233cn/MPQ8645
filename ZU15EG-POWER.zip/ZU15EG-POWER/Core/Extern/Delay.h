#ifndef __DELAY_H
#define __DELAY_H
#include "main.h"


void Delay_us(uint16_t delay_time);

#endif