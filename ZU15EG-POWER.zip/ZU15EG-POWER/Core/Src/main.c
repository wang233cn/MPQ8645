/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "I2C.h"
#include "MPQ8645.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
MPQ8645_ValueTypeDef MPQ8645_Value;
MPQ8645_StatusTypeDef MPQ8645_Status;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PG_State HAL_GPIO_ReadPin(GPIOA,PG_INT_Pin)
#define KEY_State HAL_GPIO_ReadPin(GPIOA,POWER_KEY_Pin)

#define LEDY_ON  HAL_GPIO_WritePin(GPIOB,LED_Y_Pin,GPIO_PIN_SET)
#define LEDY_OFF HAL_GPIO_WritePin(GPIOB,LED_Y_Pin,GPIO_PIN_RESET)

#define LEDB_ON  HAL_GPIO_WritePin(GPIOB,LED_B_Pin,GPIO_PIN_SET)
#define LEDB_OFF HAL_GPIO_WritePin(GPIOB,LED_B_Pin,GPIO_PIN_RESET)


#define DC_EN1_H HAL_GPIO_WritePin(GPIOA,DC_EN1_Pin,GPIO_PIN_SET)    //VCC_PSINT
#define DC_EN1_L HAL_GPIO_WritePin(GPIOA,DC_EN1_Pin,GPIO_PIN_RESET)
#define DC_EN2_H HAL_GPIO_WritePin(GPIOA,DC_EN2_Pin,GPIO_PIN_SET)    //VCC_PLINT
#define DC_EN2_L HAL_GPIO_WritePin(GPIOA,DC_EN2_Pin,GPIO_PIN_RESET)
#define DC_EN3_H HAL_GPIO_WritePin(GPIOA,DC_EN3_Pin,GPIO_PIN_SET)    //MGT_AVCC
#define DC_EN3_L HAL_GPIO_WritePin(GPIOA,DC_EN3_Pin,GPIO_PIN_RESET)
#define DC_EN4_H HAL_GPIO_WritePin(GPIOA,DC_EN4_Pin,GPIO_PIN_SET)    //MGT_AVTT
#define DC_EN4_L HAL_GPIO_WritePin(GPIOA,DC_EN4_Pin,GPIO_PIN_RESET)
#define DC_EN5_H HAL_GPIO_WritePin(GPIOA,DC_EN5_Pin,GPIO_PIN_SET)    //DDR_1V2
#define DC_EN5_L HAL_GPIO_WritePin(GPIOA,DC_EN5_Pin,GPIO_PIN_RESET)
#define DC_EN6_H HAL_GPIO_WritePin(GPIOA,DC_EN6_Pin,GPIO_PIN_SET)    //VCC_AUX
#define DC_EN6_L HAL_GPIO_WritePin(GPIOA,DC_EN6_Pin,GPIO_PIN_RESET)
#define DC_EN7_H HAL_GPIO_WritePin(GPIOA,DC_EN7_Pin,GPIO_PIN_SET)    //PL_DDR4_VPP
#define DC_EN7_L HAL_GPIO_WritePin(GPIOA,DC_EN7_Pin,GPIO_PIN_RESET)
#define DC_EN8_H HAL_GPIO_WritePin(GPIOA,DC_EN8_Pin,GPIO_PIN_SET)    //PS_DDR4_VPP
#define DC_EN8_L HAL_GPIO_WritePin(GPIOA,DC_EN8_Pin,GPIO_PIN_RESET)
#define DC_EN9_H HAL_GPIO_WritePin(GPIOB,DC_EN9_Pin,GPIO_PIN_SET)    //MGT_AVCCAUX
#define DC_EN9_L HAL_GPIO_WritePin(GPIOB,DC_EN9_Pin,GPIO_PIN_RESET)
#define DC_EN10_H HAL_GPIO_WritePin(GPIOB,DC_EN10_Pin,GPIO_PIN_SET)    //PS_AVCC
#define DC_EN10_L HAL_GPIO_WritePin(GPIOB,DC_EN10_Pin,GPIO_PIN_RESET)
#define DC_EN11_H HAL_GPIO_WritePin(GPIOA,DC_EN11_Pin,GPIO_PIN_SET)    //PS_AVTT
#define DC_EN11_L HAL_GPIO_WritePin(GPIOA,DC_EN11_Pin,GPIO_PIN_RESET)
#define DC_EN12_H HAL_GPIO_WritePin(GPIOA,DC_EN12_Pin,GPIO_PIN_SET)    //VCC_3V3
#define DC_EN12_L HAL_GPIO_WritePin(GPIOA,DC_EN12_Pin,GPIO_PIN_RESET)

#define ZU15EG_EN HAL_GPIO_WritePin(GPIOA,ARM_nPOR_Pin,GPIO_PIN_SET)
#define ZU15EG_DISEN HAL_GPIO_WritePin(GPIOA,ARM_nPOR_Pin,GPIO_PIN_RESET)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void Power_Fault(void);
void PowerON_Sequence(void);
void Power_Down(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
	
	LEDB_OFF;
  LEDY_OFF;
	
	PowerON_Sequence();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
//		I2C_Read(MPQ8645_ADDR,MFR_CTRL_VOUT,Test_data,1);
//		I2C_Read(MPQ8645_ADDR,VOUT_COMMAND,Test_data,2);
//		I2C_Read(MPQ8645_ADDR,VOUT_SCALE_LOOP,Test_data,2);
//		I2C_Read(MPQ8645_ADDR,READ_VOUT,Test_data,2);

		if(HAL_GPIO_ReadPin(GPIOA,PG_INT_Pin)) LEDB_ON;
		else{
			LEDB_OFF;
			Power_Fault();
		}
    MPQ8645_GetValue(&MPQ8645_Value);
		MPQ8645_GetStatus(&MPQ8645_Status);
//		if(PG_State == 1){
//			Power_Fault();
//		}
//		HAL_GPIO_TogglePin(GPIOB,LED_B_Pin);
		HAL_Delay(99);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_4;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void PowerON_Sequence(void){
	ZU15EG_DISEN;
	MPQ8645_Init();
	
//LPD
//1. VCC_PSINTLP
//2. VCC_PSAUX, VCC_PSADC, and VCC_PSPLL in any order or simultaneously.
//3. VCCO_PSIO
	
//FPD
//1. VCC_PSINTFP and VCC_PSINTFP_DDR driven from the same supply source.
//2. VPS_MGTRAVCC and VCC_PSDDR_PLL in any order or simultaneously.
//3. VPS_MGTRAVTT and VCCO_PSDDR in any order or simultaneously
	
//PL VCCINT, VCCINT_IO/VCCBRAM, VCCINT_VCU, VCCAUX/VCCAUX_IO	
  DC_EN1_H;  //PSINT
	DC_EN2_H;  //PLINT
	HAL_Delay(20);
	
  DC_EN6_H;
	HAL_Delay(20);
	
	DC_EN4_H;DC_EN10_H;	DC_EN7_H;DC_EN8_H;;DC_EN9_H;

	HAL_Delay(20);
	
	DC_EN11_H; DC_EN5_H;	DC_EN3_H;
	HAL_Delay(20); 

	DC_EN12_H;
	HAL_Delay(20);

	while(!HAL_GPIO_ReadPin(GPIOA,PG_INT_Pin))	ZU15EG_EN;
	
}

void Power_Down(void){
	ZU15EG_DISEN;
	DC_EN12_L;
	HAL_Delay(20);
	DC_EN11_L;
	HAL_Delay(20);
	DC_EN10_L;
	HAL_Delay(20);
	DC_EN9_L;
	HAL_Delay(20);
	DC_EN8_L;
	HAL_Delay(20);
	DC_EN7_L;
	HAL_Delay(20);
	DC_EN6_L;
	HAL_Delay(20);
	DC_EN5_L;
	HAL_Delay(20);
	DC_EN4_L;
	HAL_Delay(20);
	DC_EN3_L;
	HAL_Delay(20);
	DC_EN2_L;
	HAL_Delay(20);
	DC_EN1_L;
	HAL_Delay(20);
}

void Power_Fault(void){
	Power_Down();
	for(;;){
		HAL_GPIO_TogglePin(GPIOB,LED_Y_Pin);
		if(KEY_State == 0){
			HAL_Delay(20);
			if(KEY_State == 0){
				PowerON_Sequence(); 
				break;
			}
		}	
		HAL_Delay(99);
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
